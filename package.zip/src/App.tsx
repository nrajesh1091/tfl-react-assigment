
import './App.css'
import { AppConfigContext } from '@contexts/AppContext'
import ErrorBoundary from '@components/error-boundary'
import { Home } from '@features/home'
import { LoaderProvider } from '@contexts/LoaderContext'
import { useEffect, useState } from 'react'
import { Header } from '@components/header'
import { Footer } from '@components/footer'
 function App() {
  const [config,setConfig] = useState();
  useEffect(()=>{
    (async()=>{
    const res = await fetch("./assets/config.json");
    const data = await res.json()
    setConfig(data)
    })()
  },[])


  return (
    <LoaderProvider>
      <ErrorBoundary>
        <AppConfigContext AppConfigData={config}>
          <Header></Header>
          <h1>Transport for London Tube Status</h1>
          <Home>

          </Home>
        </AppConfigContext>
        <Footer></Footer>
      </ErrorBoundary>
    </LoaderProvider>
  )
}

export default App
