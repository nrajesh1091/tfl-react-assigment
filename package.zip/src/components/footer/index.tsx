export const Footer=()=>{
    return <footer className="flex  bg-[#202329] min-h-[60px]">
        <span className="p-1 m-1 text-white">Contact Us</span>
    </footer>
}