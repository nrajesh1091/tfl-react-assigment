export type AppConfig ={
    "apiDomain":string,
    "apiKey":string,
    "appID":string
} | null ;